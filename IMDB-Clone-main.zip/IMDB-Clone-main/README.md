# IMDB-Clone
This is my Frontend project using HTML CSS, JAVASCRIPT &amp; API


# Home Page
![WhatsApp Image 2023-05-20 at 15 29 23](https://github.com/Mohdhamidashraf/IMDB-Clone/assets/134134999/1c600cea-6571-4658-a319-783feaa72cff)
